import e from"./en.6917c3f0.js";import o from"./es.5e04d79e.js";const a=()=>({legacy:!1,locale:"es",messages:{es:o,en:e}});export{a as default};
