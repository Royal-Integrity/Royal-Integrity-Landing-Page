import e from"./en.06d1cf48.js";import o from"./es.d2de9936.js";const a=()=>({legacy:!1,locale:"es",messages:{es:o,en:e}});export{a as default};
