import"./entry.5e86a965.js";const s=""+globalThis.__publicAssetsURL("videos/logo.mp4");export{s as _};
