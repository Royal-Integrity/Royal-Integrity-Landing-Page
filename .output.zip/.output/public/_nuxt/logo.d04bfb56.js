import"./entry.95a85cc8.js";const s=""+globalThis.__publicAssetsURL("videos/logo.mp4");export{s as _};
